import express  from "express";
import {jwtlogined} from "../controllers/auth/auth.js";
const router = express.Router();

router.get("/",jwtlogined,(req,res)=>{
    res.render("index",{
        user: req.user
    });
})

router.get("/register",(req,res)=>{
    res.render("register");
})


router.get("/login",(req,res) => {
    res.render("login");
})


router.get("/profile",jwtlogined,(req,res) => {
        if(req.user) {
            res.render("profile",{
                user:req.user
            });
            
        } else {
            res.redirect("login");
        }
    })

export default router;