import express from "express";
import {authregister, authLogin, logoutAuth} from "../controllers/auth/auth.js";

const router = express.Router();

router.post("/register",authregister);

router.post("/login",authLogin);

router.get("/logout",logoutAuth);


export default  router;