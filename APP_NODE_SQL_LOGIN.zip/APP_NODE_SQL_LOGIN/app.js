import  express  from "express";
import db from "./database/db.js";
import path from "path";
import { fileURLToPath } from "url";
import pageRouter from "./routes/pages.js";
import authRoute from "./routes/auth.js";
import cookieparser from "cookie-parser";

const app = express();
const port = 9000;
const routers = express.Router();



//use to known to node js to except any type of data in my case its data come from html form
app.use(express.urlencoded({extended:false}));

//tell the node to parse data in json formated
app.use(express.json());
app.use(cookieparser());


//connect db
db.connect((error,result) =>{
    if(error) {
        console.log("ERROR WHILING CONNECTING TO DATABASE::", error);
    } else {
        console.log("DATABASE CONNECTED...");
    }
})
app.set("view engine","hbs");

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
//public file connect 
const publicDirectory = path.join(__dirname,"./public");
app.use(express.static(publicDirectory)); 


//routes 
app.use("/",pageRouter);
app.use("/auth",authRoute);




app.listen(port,()=>{
    console.log(`APP RUNNING ON PORT ${port}`);
})