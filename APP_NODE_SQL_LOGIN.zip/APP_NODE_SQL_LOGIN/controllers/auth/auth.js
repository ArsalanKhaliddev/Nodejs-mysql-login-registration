import db from "../../database/db.js";
import bcrpt from "bcrypt";
import  jwt  from "jsonwebtoken";
import {promisify} from "util";
// import cookies from "cookie-parser"

//register
export const authregister =  (req,res) => {
    
    const {name,email,password,confrimPassword} = req.body;
 
    if(!email || !name || !password || !confrimPassword ) {
        return  res.render("register",{
              message:"PLEASE Fill ALL THE FIELDS",
              class:"field_required"
          })
      } else if(password !== confrimPassword ) {
          return  res.render("register",{
              message: "PASSWORD NOT MATCH",
              class:"password_notmatch"
          })
      }

    db.query("SELECT email FROM users WHERE email = ?",[email], async (error,result) =>{
            if(error) {
                console.log(error);
            } 
            
            if(result?.length > 0) {
                return res.render("register",{
                    message: "User is Already exit",
                    class:"user_alreadexit"
                })

            }  
                
            const hashPassword = await bcrpt.hash(password,8);

            db.query("INSERT INTO users SET ?",{name:name,email:email,password:hashPassword},(error,result) => {
                if(error) {
                    console.log(error);
                }  else {
                    console.log(result)
                        res.render("register",{
                            message:"user added suceesfully",
                            class:"user_added"
                        })
                }
            })
    })




}



//login

export const authLogin = async (req,res) => {
    try {
        const {email , password} = req.body;

        if(!email || !password) {
            res.status(400).render("login",{
                message:"please provide email and password",
                class:"error_login"
            })
        }

        db.query("SELECT * FROM users WHERE email = ?",[email],async (error,result) => {
            console.log(result)

            let passresolved = await bcrpt.compare(password , result[0].password);

            console.log("passresolved",passresolved)
             if( !result || !passresolved ) {
                return  res.status(400).render("login",{
                    message: "wrong email and password"
                })
            } else {
                    let id = result[0].id;
                    const token = jwt.sign({id},process.env.JWT_SECRET,{
                        expiresIn: process.env.JWT_EXPIRE_IN
                    })

                    console.log(token);

                    const cookieOptions = {
                        expires: new Date(
                            Date.now() + process.env.JWT_COOKIE_EXPIRE * 24 * 60 * 60 * 1000
                        ),
                        httpOnly: true
                    }

                    res.cookie("jwt",token,cookieOptions);
                    res.status(200).redirect("/");
            }

        } )

    } catch(error) {
        console.log(error);
    }
    
}

//logined

export const jwtlogined = async (req,res,next) => {


    if (req.cookies.jwt) {
        try {
          // 1) verify token
          const decoded = await promisify(jwt.verify)(
            req.cookies.jwt,
            process.env.JWT_SECRET
          );
    
          console.log("decoded");
          console.log(decoded);

          // 2) find user is exit in db
          db.query("SELECT * FROM users WHERE  id = ?",[decoded.id],(error,result) => {
                if(!result) {
                    return next();
                }
                req.user = result[0];
                return next();
          })
        }catch(error) {
            console.log(error);
        }
    } else {
    next();

    }
}


//logout

export const logoutAuth =  (req,res) => {
    res.cookie('jwt', 'loggedout', {
        expires: new Date(Date.now() + 1 ),
        httpOnly: true
      });
      res.status(200).redirect("/");
}